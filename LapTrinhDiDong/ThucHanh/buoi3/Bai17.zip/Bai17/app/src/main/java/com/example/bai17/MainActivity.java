package com.example.bai17;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.view.View.OnClickListener;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button btnThem, btnXem, btnQuanLy;
    static int status = -1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(status == -1) {
            ArrayList<BaiHat> lstBH = new ArrayList<>();
            ArrayList<BaiHat> lstBH1 = new ArrayList<>();
            BaiHat bh = new BaiHat("Kia sao be khong lac", "05/05/2002");
            BaiHat bh1 = new BaiHat("Chau len ba", "05/05/2002");
            BaiHat bh2 = new BaiHat("Con co be be", "05/05/2002");
            BaiHat bh3 = new BaiHat("Bat Kim Thang", "05/05/2002");
            lstBH.add(bh);
            lstBH.add(bh1);
            Album album = new Album("Album 1", "Thủy Tiên không thích sao kê", lstBH);
            lstBH1.add(bh2);
            lstBH1.add(bh3);
            Album album2 = new Album("Album 2", "Cô Hằng thì thích sao kê", lstBH1);
            AlbumActivity.lst.add(album);
            AlbumActivity.lst.add(album2);
            status = 11231;
        }
        getWigets();
        btnXem.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AlbumActivity.class);
                startActivity(intent);
            }
        });
        btnThem.setOnClickListener(callDialog);
        btnQuanLy.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, QuanLyActivity.class);
                startActivity(intent);
            }
        });


    }

    private void getWigets() {
        btnQuanLy = (Button) findViewById(R.id.btnQL);
        btnThem = (Button) findViewById(R.id.btnThem);
        btnXem = (Button) findViewById(R.id.btnXem);
    }

    OnClickListener callDialog = new OnClickListener() {
        @Override
        public void onClick(View view) {

            buttonOpenDialogClicked();
        }
    };
    private void buttonOpenDialogClicked()  {
        CustomDialog.AddAlbumListener listener = new CustomDialog.AddAlbumListener() {
            @Override
            public void addAlbumEntered(String addAlbum) {

            }
        };
        final CustomDialog dialog = new CustomDialog(this, listener);

        dialog.show();
    }
}
